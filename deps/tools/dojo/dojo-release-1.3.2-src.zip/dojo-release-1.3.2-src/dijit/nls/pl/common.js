({
	buttonOk: "OK",
	buttonCancel: "Anuluj",
	buttonSave: "Zapisz",
	itemClose: "Zamknij"
})
