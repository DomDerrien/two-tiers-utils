// looks like a function

var Item = function(pid) {
	/** The item name */
	this.name = function(n) {
	}(pid);
};

/** The price */
Item.Price = function(n) {
}(1.99);

/** The product */
Product = new function(pid) {
	/** The seller */
	this.seller = "Acme";
}
