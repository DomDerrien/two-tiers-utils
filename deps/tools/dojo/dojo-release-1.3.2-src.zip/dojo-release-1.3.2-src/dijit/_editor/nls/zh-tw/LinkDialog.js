({
	createLinkTitle: "鏈結內容",
	insertImageTitle: "影像檔內容",
	url: "URL：",
	text: "說明：",
	set: "設定"
})
