({
	loadingState: "Chargement...",
	errorState: "Une erreur est survenue"
})
